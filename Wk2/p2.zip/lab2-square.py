# CS 122 Fall 2023 Lab 2
# Author: Oliver Boorstein
# Partner:
# Description: Create a function that returns the square of any positive integer


# Define a function that will accept a number
def square(num):
    # Check that number is a positive integer
    # Insert conditonal that I totally do not know yet here

    # Multiply number by itself and return result
    return pow(num, 2)


# Test
print(f"{square(2)}, {square(10)}, {square(100)}")