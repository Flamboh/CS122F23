cost = 50
# type(cost)
discount = 0.10
# type(discount)
discounted_cost = cost - cost * discount
# discounted_cost
# print("Discounted cost", discounted_cost)
discounted_label = "Discounted cost:"
print(discounted_label, discounted_cost)