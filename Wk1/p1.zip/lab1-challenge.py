# CS 122 Fall 2023 Lab 1 Challenge
# Author: Oliver Boorstein
# Credit:
# Description: Lab 1 challenge assignment

# day = Monday
day = 'Monday'

# square = 2 ^ 2
square = 2 ** 2

# print square
print(square)

# print(day + square)
print(day, square)
